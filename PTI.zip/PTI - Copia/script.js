// ============================
// 1) Validação simples do formulário
// ============================
const form = document.getElementById("form-contato");

form.addEventListener("submit", function(event) {
  event.preventDefault(); // impede o reload da página
  alert("✅ Mensagem enviada com sucesso! Entraremos em contato em breve.");
  form.reset(); // limpa os campos do formulário
});

// ============================
// 2) Menu hambúrguer no celular
// ============================
const menuToggle = document.createElement("button");
menuToggle.innerText = "☰"; // ícone do menu
menuToggle.id = "menu-toggle";
document.querySelector("header").appendChild(menuToggle);

const nav = document.querySelector("header nav");

menuToggle.addEventListener("click", () => {
  nav.classList.toggle("ativo"); // alterna a classe "ativo"
});
